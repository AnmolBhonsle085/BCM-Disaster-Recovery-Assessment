# Evidence

Add screenshots only after you perform the corresponding hands-on tests. Suggested evidence:
- backup-created.png
- simulated-failure.png
- restore-process.png
- recovery-success.png

Do not use fabricated screenshots or fabricated recovery times.