# BCM & Disaster Recovery Assessment

## Overview
Portfolio project assessing business continuity and disaster recovery for a simulated SaaS organization.

**Important:** The organization and environment are simulated for educational purposes. This is not a real client assessment, external audit, or certification engagement.

## Project flow
1. Project scope
2. Organization profile
3. IT environment
4. Business Impact Analysis (BIA)
5. RTO/RPO definition
6. Disaster scenario identification
7. Risk register
8. Backup strategy
9. Disaster recovery plan
10. Controlled recovery test
11. Findings and remediation

## Evidence
The `Evidence/` folder is intentionally a placeholder. Add your own screenshots only after performing the corresponding lab actions.

## Suggested hands-on test
Use non-production sample data. Create a backup, simulate deletion, restore the data, record the timestamps, and compare actual recovery against the target RTO/RPO.

## Resume positioning
Describe this as a **BCM & Disaster Recovery Assessment — Simulated IT Environment** and do not claim it was performed for a real organization.
